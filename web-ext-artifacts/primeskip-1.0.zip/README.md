# Prime Skip

**This add-on injects JavaScript into the Amazon web page.**

## What it does

This extension just includes:

* a content script, "skip.js", that is injected into any pages
under "amazon" or any of its subdomains

The content script skips every intro.

npm install --global web-ext
web-ext run
web-ext build